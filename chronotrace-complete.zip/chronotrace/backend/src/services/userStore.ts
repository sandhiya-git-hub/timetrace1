import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { randomBytes } from 'crypto';
import { DATA_DIR } from '../config/env.js';
import type { UserRecord, AuthSession } from '../types/models.js';
import { normalizeEmail, normalizeUsername } from '../../../shared/validation/auth.js';

const usersPath = path.join(DATA_DIR, 'users.json');
const authSessionsPath = path.join(DATA_DIR, 'auth_sessions.json');

// Thrown when a store file exists but cannot be read or parsed. Callers must fail the
// request. Returning an empty list here would make every login fail and, on the next
// save, overwrite the real accounts with an empty file.
export class UserStoreError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UserStoreError';
  }
}

export const newDeviceToken = (): string => `ct_dev_${randomBytes(24).toString('hex')}`;

// Write to a temp file, then rename. A crash mid-write leaves the old file intact.
const writeJsonAtomic = (file: string, data: unknown) => {
  const tmp = `${file}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`;
  try {
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tmp, file);
  } catch (error) {
    try {
      fs.unlinkSync(tmp);
    } catch {
      // Temp file may not exist if the write itself failed.
    }
    throw error;
  }
};

const readJsonFile = (file: string): unknown => {
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (error) {
    throw new UserStoreError(`${path.basename(file)} could not be read: ${(error as Error).message}`);
  }
};

export const getUsers = (): UserRecord[] => {
  const raw = readJsonFile(usersPath);
  if (raw === null) return [];
  if (!Array.isArray(raw)) {
    throw new UserStoreError('users.json must contain a JSON array of accounts.');
  }

  let changed = false;
  // Normalize legacy records. Older files may lack username, email, id, deviceToken or
  // givenName, or store a plain `password`. Missing fields become empty strings so no
  // lookup can call .toLowerCase() on undefined.
  const migrated: UserRecord[] = raw.map((entry: any, idx: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new UserStoreError(`users.json entry ${idx} is not an account object.`);
    }
    const updated: any = { ...entry };

    if (!updated.id) {
      updated.id = `usr_${randomBytes(12).toString('hex')}`;
      changed = true;
    }
    const username = normalizeUsername(updated.username);
    if (username !== updated.username) {
      updated.username = username;
      changed = true;
    }
    const email = normalizeEmail(updated.email);
    if (email !== updated.email) {
      updated.email = email;
      changed = true;
    }
    if (!updated.deviceToken) {
      updated.deviceToken = newDeviceToken();
      changed = true;
    }
    if (updated.password && !updated.passwordHash) {
      updated.passwordHash = bcrypt.hashSync(String(updated.password), 10);
      delete updated.password;
      changed = true;
    }
    if (typeof updated.passwordHash !== 'string') {
      updated.passwordHash = '';
      changed = true;
    }
    if (!updated.name) {
      updated.name = updated.username || 'User';
      changed = true;
    }
    if (!updated.givenName) {
      updated.givenName = String(updated.name).split(' ')[0] || 'User';
      changed = true;
    }
    return updated as UserRecord;
  });

  if (changed) {
    saveUsers(migrated);
  }
  return migrated;
};

export const saveUsers = (users: UserRecord[]) => {
  writeJsonAtomic(usersPath, users);
};

export const getAuthSessions = (): Record<string, AuthSession> => {
  const raw = readJsonFile(authSessionsPath);
  if (raw === null) return {};
  if (typeof raw !== 'object' || Array.isArray(raw)) {
    throw new UserStoreError('auth_sessions.json must contain a JSON object.');
  }
  return raw as Record<string, AuthSession>;
};

export const saveAuthSessions = (sessions: Record<string, AuthSession>) => {
  writeJsonAtomic(authSessionsPath, sessions);
};
