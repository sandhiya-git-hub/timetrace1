import express from 'express';
import cookieParser from 'cookie-parser';
import authRoutes from './routes/auth.routes.js';
import agentRoutes from './routes/agent.routes.js';
import deviceRoutes from './routes/device.routes.js';
import analyticsRoutes from './routes/analytics.routes.js';
import aiRoutes from './routes/ai.routes.js';
import { requireSessionUser } from './services/authHelpers.js';

export const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());

// Every data route requires a signed-in session (except the explicit public/agent routes).
app.use(requireSessionUser);

// All route files declare their full paths (/api/...), so they mount at the root.
app.use(authRoutes);
app.use(agentRoutes);
app.use(deviceRoutes);
app.use(analyticsRoutes);
app.use(aiRoutes);

// Every API error is returned as JSON. Without this, Express sends an HTML page, and the
// browser's JSON parsing fails with a confusing message instead of the real error.
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (res.headersSent) return next(err);
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'The request body must be valid JSON.' });
  }
  if (err?.type === 'entity.too.large') {
    return res.status(413).json({ error: 'The request is too large.' });
  }
  if (err?.name === 'UserStoreError') {
    console.error(`[store] ${req.method} ${req.path}: ${err.message}`);
    return res.status(500).json({
      error: 'Account storage could not be read or saved. Please try again later.',
    });
  }
  console.error(`[api] ${req.method} ${req.path} failed:`, err);
  return res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
});
