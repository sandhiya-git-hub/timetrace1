import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// -------------------------------------------------------------
// AI ASSISTANT CHAT ENDPOINT (Context Grounded in Real User Activity)
// -------------------------------------------------------------

router.post('/api/assistant/chat', async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const user = res.locals.user as UserRecord;
    const summary = getUserSummary(user.id);
    const sessions = getUserSessions(user.id);
    const telemetry = getUserTelemetry(user.id);
    const rec = getUserDeviceRecord(user.id);

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY not configured' });
    }

    const todayDate = rec.lastLocalDate || new Date().toISOString().split('T')[0];
    const hasData = telemetry.length > 0 || sessions.length > 0;

    const systemPrompt = hasData
      ? `You are ChronoTrace Assistant, a private, intelligent activity reconstruction assistant created with Google-level simplicity, clarity, and precision.
You answer user questions strictly based on their real, captured computer activity from the ChronoTrace Windows Agent today (${todayDate}).
User Name: ${user.name} (${user.username}).

REAL USER DATA TODAY:
1. Daily Synthesis Summary:
${JSON.stringify(summary, null, 2)}

2. Reconstructed Activity Timeline (Cognitive Chunks):
${JSON.stringify(sessions.slice(-15), null, 2)}

3. Recent Telemetry Window Switches:
${JSON.stringify(telemetry.slice(-20), null, 2)}

GUIDELINES:
- Base your answers ONLY on this user's captured telemetry and cognitive sessions.
- Accurately mention specific application names, window titles, exact durations in minutes/seconds, and intent categories.
- Respect their device's local date (${todayDate}) and timestamps.
- Be concise, direct, helpful, and objective.`
      : `You are ChronoTrace Assistant.
User Name: ${user.name} (${user.username}).
IMPORTANT: No telemetry activity or work sessions have been recorded for this account yet today (${todayDate}). The Windows agent is not streaming events yet.
GUIDELINES:
- Honestly and clearly state that no computer activity or focus sessions have been recorded yet today.
- Do NOT invent or hallucinate any session data, application names, or durations.
- Explain that once they run the ChronoTrace agent on their Windows machine, their real foreground windows and focus sessions will be reconstructed and ready for analysis.`;

    const contents: any[] = [{ role: 'user', parts: [{ text: systemPrompt }] }];

    if (Array.isArray(conversationHistory)) {
      for (const msg of conversationHistory) {
        if (msg.role === 'user' || msg.role === 'assistant') {
          contents.push({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }],
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
    });

    const answer = response.text || 'I analyzed your activity stream.';
    res.json({
      role: 'assistant',
      content: answer,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });
  } catch (error: any) {
    console.error('Assistant error:', error);
    res.status(500).json({ error: error.message || 'Error generating assistant response' });
  }
});

router.post('/api/gemini/synthesize-day', async (req, res) => {
  try {
    const user = res.locals.user as UserRecord;
    const sessions = req.body.sessions || getUserSessions(user.id);
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY not configured' });
    }

    const promptText = `Synthesize full-day cognitive activity from these session chunks:
${JSON.stringify(sessions, null, 2)}

Provide strict JSON output:
- total_deep_work_s: int
- total_distraction_s: int
- fragmentation_score: float 0-10
- peak_focus_window: string
- context_switches: int
- distraction_triggers: array of strings
- daily_narrative: 2-3 sentences narrative
- unfinished_work: array of strings`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const currentSummary = getUserSummary(user.id);
    const updated = { ...currentSummary, ...parsed };
    saveUserSummary(user.id, updated);
    res.json(updated);
  } catch (error: any) {
    console.error('Gemini day synthesis error:', error);
    res.status(500).json({ error: error.message || 'Gemini error' });
  }
});


export default router;
