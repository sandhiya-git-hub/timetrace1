import React from 'react';
import { ArrowRight, Clock, Shield } from 'lucide-react';

interface SplashScreenProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

// Describes only what ChronoTrace does. It shows no sample activity, metrics or percentages.
const HOW_IT_WORKS = [
  {
    title: 'Capture',
    body: 'The desktop agent records app and window titles as you work. No keystrokes or screenshots.',
  },
  {
    title: 'Reconstruct',
    body: 'Activity is grouped into sessions on a timeline. You can read it and correct any session.',
  },
  {
    title: 'Resume',
    body: 'Re-entry briefings show where you left off, so you can pick the thread back up.',
  },
];

export const SplashScreen: React.FC<SplashScreenProps> = ({ onGetStarted, onSignIn }) => {
  return (
    <div className="relative min-h-screen overflow-hidden bg-slate-50 font-sans text-slate-900 selection:bg-blue-100">
      {/* Ambient background: soft gradient and a faint dot grid */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="ct-glow absolute -top-40 -left-32 h-[32rem] w-[32rem] rounded-full bg-gradient-to-br from-blue-200/70 to-indigo-100/40 blur-3xl" />
        <div className="ct-glow ct-glow-delayed absolute -bottom-48 -right-32 h-[30rem] w-[30rem] rounded-full bg-gradient-to-tr from-emerald-100/70 to-cyan-100/40 blur-3xl" />
        <div
          className="absolute inset-0 opacity-[0.35]"
          style={{
            backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)',
            backgroundSize: '24px 24px',
            maskImage: 'linear-gradient(to bottom, black 20%, transparent 85%)',
            WebkitMaskImage: 'linear-gradient(to bottom, black 20%, transparent 85%)',
          }}
        />
      </div>

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-6xl flex-col px-5 sm:px-8">
        {/* Header */}
        <header className="flex items-center justify-between py-6">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-600/25">
              <Clock className="h-4 w-4 stroke-[2.2]" />
            </div>
            <span className="text-base font-semibold tracking-tight text-slate-900">ChronoTrace</span>
          </div>
          <button
            type="button"
            onClick={onSignIn}
            className="cursor-pointer rounded-lg px-3.5 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-white hover:text-slate-900"
          >
            Sign in
          </button>
        </header>

        {/* Hero */}
        <main className="grid flex-1 items-center gap-12 py-10 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16 lg:py-16">
          <section className="text-center lg:text-left">
            <p
              className="ct-fade-up mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white/80 px-3 py-1 text-xs font-medium text-slate-600 shadow-sm backdrop-blur lg:mx-0"
              style={{ animationDelay: '0ms' }}
            >
              <Shield className="h-3.5 w-3.5 text-emerald-600" />
              Passive activity reconstruction
            </p>

            <h1
              className="ct-fade-up text-4xl font-bold leading-[1.08] tracking-tight text-slate-900 sm:text-5xl lg:text-6xl"
              style={{ animationDelay: '80ms' }}
            >
              Your workday,{' '}
              <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-500 bg-clip-text text-transparent">
                reconstructed.
              </span>
            </h1>

            <p
              className="ct-fade-up mx-auto mt-6 max-w-xl text-base leading-relaxed text-slate-600 sm:text-lg lg:mx-0"
              style={{ animationDelay: '160ms' }}
            >
              ChronoTrace turns the apps and windows you use into a readable timeline, so you can see where your
              day went and pick up where you left off.
            </p>

            <div
              className="ct-fade-up mt-9 flex flex-col items-stretch justify-center gap-3 sm:flex-row lg:justify-start"
              style={{ animationDelay: '240ms' }}
            >
              <button
                type="button"
                onClick={onGetStarted}
                className="group inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-blue-600/25 transition-all hover:-translate-y-0.5 hover:bg-blue-700 active:translate-y-0 active:bg-blue-800"
              >
                <span>Get Started</span>
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button
                type="button"
                onClick={onSignIn}
                className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-sm font-semibold text-slate-800 shadow-sm transition-colors hover:border-slate-400 hover:bg-slate-50"
              >
                <span>Sign In</span>
              </button>
            </div>
          </section>

          {/* How it works: a timeline that draws itself in */}
          <section
            aria-label="How ChronoTrace works"
            className="ct-fade-up relative mx-auto w-full max-w-md rounded-2xl border border-slate-200/80 bg-white/85 p-6 shadow-xl shadow-slate-900/5 backdrop-blur sm:p-7"
            style={{ animationDelay: '320ms' }}
          >
            <p className="mb-6 text-xs font-semibold uppercase tracking-wider text-slate-400">How it works</p>

            <ol className="relative">
              {/* Track: draws from top to bottom */}
              <span
                aria-hidden="true"
                className="ct-track absolute left-[11px] top-3 bottom-3 w-0.5 origin-top rounded-full bg-gradient-to-b from-blue-500 via-indigo-400 to-emerald-400"
              />
              {/* Travelling marker along the track */}
              <span
                aria-hidden="true"
                className="ct-marker absolute left-[6px] h-3 w-3 rounded-full bg-blue-500 shadow-[0_0_0_4px_rgba(59,130,246,0.18)]"
              />

              {HOW_IT_WORKS.map((step, index) => (
                <li
                  key={step.title}
                  className="ct-step relative flex gap-4 pb-7 last:pb-0"
                  style={{ animationDelay: `${520 + index * 180}ms` }}
                >
                  <span className="relative z-10 mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 border-blue-500 bg-white text-[11px] font-bold text-blue-600">
                    {index + 1}
                  </span>
                  <div>
                    <h2 className="text-sm font-semibold text-slate-900">{step.title}</h2>
                    <p className="mt-1 text-sm leading-relaxed text-slate-600">{step.body}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        </main>

        {/* Footer */}
        <footer className="py-6 text-center text-xs text-slate-400">
          <p>Captures app and window titles only. No keystroke contents or screenshots are recorded.</p>
        </footer>
      </div>
    </div>
  );
};
