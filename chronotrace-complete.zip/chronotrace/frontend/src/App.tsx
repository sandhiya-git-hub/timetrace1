import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { GoogleAuthScreen } from './components/GoogleAuthScreen';
import { AppHeader } from './components/AppHeader';
import { DashboardView } from './components/DashboardView';
import { ActivityTimelineView } from './components/ActivityTimelineView';
import { RawActivityView } from './components/RawActivityView';
import { AiAssistantView } from './components/AiAssistantView';
import { DeviceModal } from './components/DeviceModal';
import { PrivacyModal } from './components/PrivacyModal';
import {
  AppScreen,
  ChunkSummary,
  DailySynthesis,
  DeviceState,
  IntentLabel,
  PrimaryNavTab,
  ReentryBriefing,
  TelemetryEvent,
  UserProfile,
} from '@shared/types/chronotrace';

export default function App() {
  // Navigation & Screen Lifecycle: 3 simple stages (Splash -> Auth -> Permanent Dashboard)
  const [screen, setScreen] = useState<AppScreen>('splash');
  const [activeTab, setActiveTab] = useState<PrimaryNavTab>('dashboard');

  // Core Data
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authStartMode, setAuthStartMode] = useState<'signin' | 'register'>('signin');
  const [device, setDevice] = useState<DeviceState | null>(null);
  const [events, setEvents] = useState<TelemetryEvent[]>([]);
  const [chunks, setChunks] = useState<ChunkSummary[]>([]);
  const [dailySummary, setDailySummary] = useState<DailySynthesis | null>(null);
  const [reentryBriefing, setReentryBriefing] = useState<ReentryBriefing | null>(null);

  // States & Modals
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [deviceModalOpen, setDeviceModalOpen] = useState<boolean>(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState<boolean>(false);
  const [initialAssistantPrompt, setInitialAssistantPrompt] = useState<string | undefined>(undefined);
  const [liveFileHandle, setLiveFileHandle] = useState<any | null>(null);

  const safeFetchJson = async (url: string) => {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  };

  const fetchDeviceStatus = async () => {
    const data = await safeFetchJson('/api/device/status');
    if (data) setDevice(data);
  };

  // Check initial authentication and fetch core datasets once on mount
  useEffect(() => {
    checkAuthAndInit();
  }, []);

  // Continuous background file watcher for live telemetry streaming from local chronotrace_live.json
  useEffect(() => {
    if (!liveFileHandle) return;
    let active = true;
    let lastContent = '';

    const syncFile = async () => {
      try {
        const file = await liveFileHandle.getFile();
        const text = await file.text();
        if (text && text !== lastContent && active) {
          lastContent = text;
          const parsed = JSON.parse(text);
          await fetch('/api/agent/sync-file', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sessions: parsed.sessions || [],
              current: parsed.current,
              userToken: user?.deviceToken,
              deviceName: parsed.deviceName || 'Windows Workstation',
              os: parsed.os,
            }),
          });
          fetchDeviceStatus();
          fetchAllActivityData();
        }
      } catch {
        // Non-fatal read attempt
      }
    };

    // Immediate initial sync
    syncFile();
    const interval = setInterval(syncFile, 1500);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [liveFileHandle, user]);

  // Live polling for continuous telemetry stream when on app screen
  useEffect(() => {
    if (screen !== 'app') return;

    const interval = setInterval(() => {
      fetchAllActivityData();
      fetchDeviceStatus();
    }, 3000);

    return () => clearInterval(interval);
  }, [screen]);

  // Bridge local Windows agent (ws://127.0.0.1:9876 & http://127.0.0.1:9876) running on user's machine to the website
  useEffect(() => {
    let active = true;
    let ws: WebSocket | null = null;
    let wsReconnectTimeout: any = null;

    const connectWebSocket = () => {
      if (!active) return;
      try {
        const socket = new WebSocket('ws://127.0.0.1:9876');
        ws = socket;

        socket.onopen = () => {
          if (!active) return;
          fetchDeviceStatus();
        };

        socket.onmessage = async (evt) => {
          if (!active) return;
          try {
            const data = JSON.parse(evt.data);
            if (data && (data.appName || data.heartbeat)) {
              await fetch('/api/ingest-event', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  appName: data.appName,
                  windowTitle: data.windowTitle,
                  overrideCategory: data.category || data.overrideCategory,
                  overrideTask: data.specificTask || data.overrideTask,
                  deltaSeconds: data.deltaSeconds || 1,
                  userToken: data.userToken || user?.deviceToken,
                  deviceName: data.deviceName,
                  os: data.os,
                  heartbeat: Boolean(data.heartbeat),
                }),
              });
              fetchDeviceStatus();
              fetchAllActivityData();
            }
          } catch {
            // Non-fatal parse error
          }
        };

        socket.onerror = () => {
          socket.close();
        };

        socket.onclose = () => {
          if (active) {
            wsReconnectTimeout = setTimeout(connectWebSocket, 3000);
          }
        };
      } catch {
        if (active) {
          wsReconnectTimeout = setTimeout(connectWebSocket, 3000);
        }
      }
    };

    connectWebSocket();

    // Fallback HTTP polling in case browser policy restricts WebSocket
    const bridgeInterval = setInterval(async () => {
      try {
        const localRes = await fetch('http://127.0.0.1:9876/', {
          mode: 'cors',
          cache: 'no-cache',
        });
        if (localRes.ok && active) {
          const localData = await localRes.json();
          if (localData && (localData.status === 'ok' || localData.heartbeat)) {
            await fetch('/api/ingest-event', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                appName: localData.appName,
                windowTitle: localData.windowTitle,
                overrideCategory: localData.category,
                overrideTask: localData.specificTask,
                deltaSeconds: localData.elapsedSeconds || 2,
                userToken: localData.userToken || user?.deviceToken,
                deviceName: localData.deviceName,
                os: localData.os,
                heartbeat: true,
              }),
            });
            fetchDeviceStatus();
            fetchAllActivityData();
          }
        }
      } catch {
        // Local agent not active on 9876
      }
    }, 2500);

    return () => {
      active = false;
      if (ws) {
        ws.onclose = null;
        ws.close();
      }
      clearTimeout(wsReconnectTimeout);
      clearInterval(bridgeInterval);
    };
  }, [user]);

  const checkAuthAndInit = async () => {
    try {
      const authRes = await safeFetchJson('/api/auth/session');
      if (authRes?.authenticated && authRes.user) {
        setUser(authRes.user);

        const devRes = await safeFetchJson('/api/device/status');
        if (devRes) setDevice(devRes);

        await fetchAllActivityData();

        // Direct access to Dashboard for authenticated users
        setScreen('app');
      } else {
        const devRes = await safeFetchJson('/api/device/status');
        if (devRes) setDevice(devRes);
      }
    } catch {
      // Non-fatal init fallback
    }
  };

  const fetchAllActivityData = async () => {
    try {
      const [eventsRes, sessionsRes, summaryRes, reentryRes] = await Promise.all([
        safeFetchJson('/api/telemetry/raw?limit=100'),
        safeFetchJson('/api/sessions'),
        safeFetchJson('/api/summary/today'),
        safeFetchJson('/api/reentry/TS%20Assignment'),
      ]);

      if (eventsRes?.events && Array.isArray(eventsRes.events)) {
        setEvents(eventsRes.events);
      } else if (Array.isArray(eventsRes)) {
        setEvents(eventsRes);
      }

      if (Array.isArray(sessionsRes)) setChunks(sessionsRes);
      if (summaryRes) setDailySummary(summaryRes);
      if (reentryRes) setReentryBriefing(reentryRes);
    } catch {
      // Retain current datasets if network hiccup occurs
    }
  };

  // Auth flow transitions: directly lands on Dashboard!
  const handleAuthSuccess = (authenticatedUser: UserProfile, _isFirstTime: boolean = false) => {
    setUser(authenticatedUser);
    fetchAllActivityData();
    fetchDeviceStatus();
    setScreen('app');
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {}
    setUser(null);
    setLiveFileHandle(null);
    setDevice(null);
    setEvents([]);
    setChunks([]);
    setDailySummary(null);
    setReentryBriefing(null);
    setScreen('splash');
  };

  const handleRefreshSummary = async () => {
    setIsSynthesizing(true);
    try {
      const res = await fetch('/api/gemini/synthesize-day', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessions: chunks }),
      });
      if (res.ok) {
        const data = await res.json();
        setDailySummary(data);
      }
    } catch (e) {
      console.error('Error refreshing summary:', e);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleCorrectIntent = async (chunkId: string, newIntent: IntentLabel) => {
    try {
      const res = await fetch(`/api/sessions/${chunkId}/correct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intent: newIntent }),
      });
      if (res.ok) {
        setChunks((prev) =>
          prev.map((c) =>
            c.chunk_id === chunkId
              ? { ...c, intent: newIntent, user_corrected: true }
              : c
          )
        );
      }
    } catch (e) {
      console.error('Error updating intent:', e);
    }
  };

  const handleNavigateToAssistantWithPrompt = (prompt?: string) => {
    setInitialAssistantPrompt(prompt);
    setActiveTab('assistant');
  };

  // -------------------------------------------------------------
  // USER JOURNEY RENDER ROUTING
  // -------------------------------------------------------------

  // Stage 1: Splash Screen
  if (screen === 'splash') {
    return (
      <SplashScreen
        onGetStarted={() => {
          setAuthStartMode('register');
          setScreen('auth');
        }}
        onSignIn={() => {
          setAuthStartMode('signin');
          setScreen('auth');
        }}
      />
    );
  }

  // Stage 2: Authentication (Google sign-in or email/username and password)
  if (screen === 'auth') {
    return (
      <GoogleAuthScreen
        initialMode={authStartMode}
        onSuccess={handleAuthSuccess}
        onBackToSplash={() => setScreen('splash')}
      />
    );
  }

  // Stage 3-6: Permanent Dashboard and Core Application (Never gated by connection)
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-100">
      {/* Persistent Navigation Header */}
      <AppHeader
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        user={user}
        device={device}
        liveFileActive={Boolean(liveFileHandle)}
        onOpenDeviceModal={() => setDeviceModalOpen(true)}
        onOpenPrivacyModal={() => setPrivacyModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Stage 3: Dashboard (Welcome, activity summary, compact connection status, and recent activity) */}
        {activeTab === 'dashboard' && (
          <DashboardView
            user={user}
            device={device}
            summary={dailySummary}
            chunks={chunks}
            events={events}
            reentry={reentryBriefing}
            onRefreshSummary={handleRefreshSummary}
            isSynthesizing={isSynthesizing}
            onNavigateToTimeline={() => setActiveTab('timeline')}
            onNavigateToAssistant={handleNavigateToAssistantWithPrompt}
            onOpenDeviceModal={() => setDeviceModalOpen(true)}
          />
        )}

        {/* Stage 4: Timeline (Reconstructed sessions) */}
        {activeTab === 'timeline' && (
          <ActivityTimelineView
            chunks={chunks}
            onCorrectIntent={handleCorrectIntent}
            onOpenDeviceModal={() => setDeviceModalOpen(true)}
          />
        )}

        {/* Stage 5: Activity (Raw recorded events) */}
        {activeTab === 'raw' && (
          <RawActivityView
            events={events}
            onOpenDeviceModal={() => setDeviceModalOpen(true)}
          />
        )}

        {/* Stage 6: AI Assistant (Ask questions about available activity and work sessions) */}
        {activeTab === 'assistant' && (
          <AiAssistantView
            initialPrompt={initialAssistantPrompt}
            hasEvents={events.length > 0 || chunks.length > 0}
            onNavigateToTimeline={() => setActiveTab('timeline')}
          />
        )}
      </main>

      {/* Dedicated Device Connection Modal Dialog */}
      {deviceModalOpen && (
        <DeviceModal
          device={device}
          userToken={user?.deviceToken}
          liveFileActive={Boolean(liveFileHandle)}
          onSetLiveFileHandle={(handle) => setLiveFileHandle(handle)}
          onStopLiveStream={() => setLiveFileHandle(null)}
          onClose={() => setDeviceModalOpen(false)}
          onRefresh={async () => {
            const devRes = await fetch('/api/device/status').then((r) => r.json());
            setDevice(devRes);
            fetchAllActivityData();
          }}
        />
      )}

      {/* Privacy Guarantee Modal */}
      {privacyModalOpen && (
        <PrivacyModal onClose={() => setPrivacyModalOpen(false)} />
      )}
    </div>
  );
}
