import path from 'path';
import { fileURLToPath } from 'url';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig, loadEnv } from 'vite';

const here = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig(({ mode }) => {
  // Read backend/.env so the dev proxy follows the same PORT as the Express API.
  const backendEnv = loadEnv(mode, path.resolve(here, '../backend'), '');
  const apiPort = backendEnv.PORT || process.env.PORT || '3000';

  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@shared': path.resolve(here, '../shared'),
      },
    },
    server: {
      // Dev only: the React app runs on :5173 and forwards /api to the Express API.
      // Without this proxy, sign-in requests reach Vite, get an empty 404, and fail.
      port: 5173,
      host: '0.0.0.0',
      hmr: false,
      proxy: {
        '/api': {
          target: `http://localhost:${apiPort}`,
          changeOrigin: false,
        },
      },
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
    },
  };
});
